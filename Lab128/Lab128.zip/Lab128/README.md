## FORMULÁRIO ##

Este trabalho teve o prazo de uma semana para ser desenvolvido
O trabalho consiste na criação de um simples formulário tematizado para uma vaga de emprego.
Neste trabalho utilizamos o Web3forms como uma ferramenta gratuita de envios de email por forms, sendo possivel entregar as mensagens com o nome email dos
"participantes".
O site possui um layout esquematizado com o padrão "hooly-grail" ou (1,3,1), sendo esse uma  dinâmica aplicada com a ferramenta de grid no css, para estilizar
o site de uma maneira padrônizada pelas demais paginas inerentes a principal.
Há também uma página específica para o erro 404 ( página não encontrada ), sendo possivel visualiza-la caso o diretório não seja encontrado pelo seever.

## Integrantes do grupo ##

# Miguel de Castilho Gengo #
RA: 24009007
# Luccas Gomes Zibordi #
RA: 24007138
# Guilherme Balabanian Mascaretti #
RA: 24021378
# Renato Henrique Ykutake Florencio #
RA: 24014446

# Links de teste #
http://localhost:3000
http://localhost:3000/forms.html
http://localhost:3000/erro

## Tecnologias utilizadas ##
# HTML #
# CSS #
# JAVASCRIPT #
# NODEJS #